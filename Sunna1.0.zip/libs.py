
##Lista de Subreddit Gerais:
#Lista do Comando --Meme
gerais = [
  'Gambiarra',
  'brasil',
  'Obotecodoreddit'
  'MemesBrasil',
  'cellbits',
  'G0ularte',
  'circojeca',
  'eu_nvr',
  'memes_br',
  'PORTUGALCARALHO',
  'brasil',
  'DiretoDoZapZap',
  'brasilivre',
  'orochinho',
]


#Lista do Comando --Animes
anime = [
  'animegifs',
  'Animemes',
  'HistoryAnimemes',
  'anime_irl',
]


#Lista do Comando --ansfw
anime2 = [
 'nsfwanimegifs',
 'AnimeNude',
 'hentai',
 'animeplot',
 'nsfwanimegifs',
 'anime_hentai',
 'ecchi',
 'doujinshi',
 'yurigif',
 'oppai_gif',
 'thighdeology',
 'ahegao',
 'MonsterGirl',
 'hentaibondage',
 'Yuri',
 'pantsu',
 'AnimeMILFS',
 'Nekomimi',
 'Paizuri',
 'AnimeBooty',
 'waifusgonewild',
 'Sukebei',
 'CumHentai',
 'Chiisaihentai',
 'Muchihentai',
 'Dekaihentai',
]
#https://www.reddit.com/r/hentai/wiki/hentai_subreddits/
#https://old.scrolller.com/hentai-subreddits

#Lista do Comando --Futebol
fut = [
  'futebol',
]


#Lista do Comando --Gifs
gif = [
  'gifs',

]


#Lista do Comando --rnsfw
realporn = [
  'MaluTrevejoOF',
  'RealGirls',
  'RiaeSuicide',
  'holdthemoan',
  'BustyPetite',
  'NSFW',
  'GoneWild',
  'CumSluts',
  'NSFW_Gifs',
  'AsiansGoneWild',
  'LegalTeens',
  'Hotchickswithtattoos',
  'hugeboobs',
  'GodPussy',
  'BelleDelphineOFNS',
]